package com.aibot.mod.keybind;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ModKeyBindings {
    public static class_304 toggleFish;
    public static class_304 toggleAttack;
    public static class_304 toggleAll;
    public static class_304 toggleRecord;
    public static class_304 togglePlayback;
    public static class_304 openPromptGui;
    public static class_304 openRecordingManager;

    public static void register() {
        toggleFish = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aimod.toggle_fish", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, class_304.class_11900.field_62556
        ));
        toggleAttack = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aimod.toggle_attack", class_3675.class_307.field_1668, GLFW.GLFW_KEY_L, class_304.class_11900.field_62556
        ));
        toggleAll = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aimod.toggle_all", class_3675.class_307.field_1668, GLFW.GLFW_KEY_SEMICOLON, class_304.class_11900.field_62556
        ));
        toggleRecord = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aimod.toggle_record", class_3675.class_307.field_1668, GLFW.GLFW_KEY_R, class_304.class_11900.field_62556
        ));
        togglePlayback = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aimod.toggle_playback", class_3675.class_307.field_1668, GLFW.GLFW_KEY_P, class_304.class_11900.field_62556
        ));
        openPromptGui = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aimod.open_prompt_gui", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, class_304.class_11900.field_62556
        ));
        openRecordingManager = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aimod.open_recording_manager", class_3675.class_307.field_1668, GLFW.GLFW_KEY_J, class_304.class_11900.field_62556
        ));
    }
}
