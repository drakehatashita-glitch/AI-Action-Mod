package com.aibot.mod.gui;

import com.aibot.mod.macro.MovementPlayback;
import com.aibot.mod.macro.MovementRecorder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class RecordingManagerScreen extends class_437 {

    private final MovementRecorder recorder;
    private final MovementPlayback playback;

    private List<String> recordings = new ArrayList<>();
    private int scrollOffset = 0;
    private static final int ROW_HEIGHT = 24;
    private static final int VISIBLE_ROWS = 10;
    private static final int LIST_X_PAD = 20;

    private String statusText = "";

    public RecordingManagerScreen(MovementRecorder recorder, MovementPlayback playback) {
        super(class_2561.method_43470("Recordings"));
        this.recorder = recorder;
        this.playback = playback;
    }

    @Override
    protected void method_25426() {
        recordings = new ArrayList<>(recorder.listRecordings());

        int closeX = field_22789 / 2 - 50;
        int closeY = field_22790 - 30;
        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(closeX, closeY, 100, 20).method_46431());

        buildRows();
    }

    private void buildRows() {
        method_37067();

        recordings = new ArrayList<>(recorder.listRecordings());

        int closeX = field_22789 / 2 - 50;
        int closeY = field_22790 - 30;
        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(closeX, closeY, 100, 20).method_46431());

        int listX = LIST_X_PAD;
        int listY = 50;
        int panelWidth = field_22789 - LIST_X_PAD * 2;
        int playBtnW = 70;
        int deleteBtnW = 60;
        int gap = 6;

        int start = scrollOffset;
        int end = Math.min(recordings.size(), scrollOffset + VISIBLE_ROWS);

        for (int i = start; i < end; i++) {
            String name = recordings.get(i);
            int rowY = listY + (i - start) * ROW_HEIGHT;
            final String finalName = name;

            int deleteX = listX + panelWidth - deleteBtnW;
            int playX = deleteX - playBtnW - gap;

            method_37063(class_4185.method_46430(class_2561.method_43470("\u25B6 Play"), b -> playRecording(finalName))
                    .method_46434(playX, rowY, playBtnW, 18).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("\u2716 Delete"), b -> {
                recorder.delete(finalName);
                statusText = "Deleted: " + finalName;
                buildRows();
            }).method_46434(deleteX, rowY, deleteBtnW, 18).method_46431());
        }

        if (scrollOffset > 0) {
            method_37063(class_4185.method_46430(class_2561.method_43470("\u25B2 Up"), b -> {
                scrollOffset = Math.max(0, scrollOffset - 1);
                buildRows();
            }).method_46434(field_22789 / 2 - 25, 28, 50, 16).method_46431());
        }

        if (scrollOffset + VISIBLE_ROWS < recordings.size()) {
            method_37063(class_4185.method_46430(class_2561.method_43470("\u25BC Down"), b -> {
                scrollOffset++;
                buildRows();
            }).method_46434(field_22789 / 2 - 25, field_22790 - 52, 50, 16).method_46431());
        }
    }

    private void playRecording(String name) {
        var frames = recorder.load(name);
        if (frames == null || frames.isEmpty()) {
            statusText = "Could not load: " + name;
            return;
        }
        if (field_22787 == null) return;
        playback.setMouseLocked(false);
        playback.start(frames, true);
        statusText = "Playing: " + name;
        method_25419();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);

        int panelWidth = field_22789 - LIST_X_PAD * 2;
        int listY = 50;

        context.method_25294(LIST_X_PAD - 4, 40, LIST_X_PAD + panelWidth + 4, listY + VISIBLE_ROWS * ROW_HEIGHT + 4, 0xBB000000);
        context.method_25300(field_22793, "\u00A7bSaved Recordings", field_22789 / 2, 8, 0xFFFFFF);
        context.method_27534(field_22793,
            class_2561.method_43470("\u00A77" + recordings.size() + " recording(s) found"), field_22789 / 2, 22, 0xAAAAAA);

        if (recordings.isEmpty()) {
            context.method_27534(field_22793,
                class_2561.method_43470("\u00A77No recordings yet. Press [R] to record."),
                field_22789 / 2, listY + 40, 0xAAAAAA);
        } else {
            int start = scrollOffset;
            int end = Math.min(recordings.size(), scrollOffset + VISIBLE_ROWS);
            for (int i = start; i < end; i++) {
                String name = recordings.get(i);
                int rowY = listY + (i - start) * ROW_HEIGHT;
                if (i % 2 == 0) {
                    context.method_25294(LIST_X_PAD - 2, rowY - 1, LIST_X_PAD + panelWidth + 2, rowY + ROW_HEIGHT - 2, 0x22FFFFFF);
                }
                context.method_27535(field_22793, class_2561.method_43470("\u00A7f" + name),
                    LIST_X_PAD + 4, rowY + 4, 0xFFFFFF);
            }
        }

        if (!statusText.isEmpty()) {
            context.method_25300(field_22793, statusText, field_22789 / 2, field_22790 - 50, 0x55FF55);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() { return false; }
}
