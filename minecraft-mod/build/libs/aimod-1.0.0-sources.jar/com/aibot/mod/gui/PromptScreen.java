package com.aibot.mod.gui;

import com.aibot.mod.macro.AiPromptExecutor;
import com.aibot.mod.macro.MovementRecorder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class PromptScreen extends class_437 {

    private static final int PADDING = 20;
    private static final int FIELD_HEIGHT = 20;
    private static final int FIELD_SPACING = 24;
    private static final int MAX_LINES = 7;
    private static final int MAX_LINE_LENGTH = 500;

    private final AiPromptExecutor promptExecutor;
    private final MovementRecorder recorder;
    private final boolean postRecording;

    private class_342 nameField = null;
    private final List<class_342> lines = new ArrayList<>();

    private class_4185 submitButton;
    private class_4185 clearButton;
    private class_4185 cancelButton;

    private String statusText = "";

    public PromptScreen(AiPromptExecutor promptExecutor) {
        this(promptExecutor, null, false);
    }

    public PromptScreen(AiPromptExecutor promptExecutor, MovementRecorder recorder, boolean postRecording) {
        super(class_2561.method_43470(postRecording ? "Save & Describe Recording" : "AI Prompt"));
        this.promptExecutor = promptExecutor;
        this.recorder = recorder;
        this.postRecording = postRecording;
    }

    @Override
    protected void method_25426() {
        lines.clear();
        nameField = null;

        int panelWidth = Math.min(field_22789 - PADDING * 2, 600);
        int panelX = (field_22789 - panelWidth) / 2;
        int currentY = PADDING + 42;

        if (postRecording) {
            nameField = new class_342(field_22793, panelX, currentY, panelWidth, FIELD_HEIGHT, class_2561.method_43473());
            nameField.method_1880(40);
            nameField.method_47404(class_2561.method_43470("Recording name (e.g. farming, fishing, combat)"));
            method_37063(nameField);
            currentY += FIELD_SPACING + 6;
        }

        int promptStartY = currentY;

        for (int i = 0; i < MAX_LINES; i++) {
            int y = promptStartY + i * FIELD_SPACING;
            class_342 field = new class_342(
                    field_22793, panelX, y, panelWidth, FIELD_HEIGHT, class_2561.method_43473()
            );
            field.method_1880(MAX_LINE_LENGTH);
            if (i == 0) {
                field.method_47404(postRecording
                        ? class_2561.method_43470("Describe extra behaviour (optional, press Enter to just save)")
                        : class_2561.method_43470("Describe what you want the AI to do... (Tab = next line)"));
            } else {
                field.method_47404(class_2561.method_43470("Continue here..."));
            }

            final int idx = i;
            field.method_1863(text -> {
                if (text.endsWith("\t")) {
                    field.method_1852(text.substring(0, text.length() - 1));
                    focusLine(idx + 1);
                }
            });

            lines.add(field);
            method_37063(field);
        }

        if (postRecording && nameField != null) {
            method_25395(nameField);
            nameField.method_25365(true);
        } else if (!lines.isEmpty()) {
            method_25395(lines.get(0));
            lines.get(0).method_25365(true);
        }

        int buttonY = promptStartY + MAX_LINES * FIELD_SPACING + 10;
        int btnW = 110;
        int gap = 8;
        int totalW = btnW * 3 + gap * 2;
        int bx = (field_22789 - totalW) / 2;

        String submitLabel = postRecording ? "Save & Run AI \u25B6" : "Send to AI \u25B6";
        submitButton = class_4185.method_46430(class_2561.method_43470(submitLabel), b -> onSubmit())
                .method_46434(bx, buttonY, btnW, 20).method_46431();
        clearButton = class_4185.method_46430(class_2561.method_43470("Clear"), b -> onClear())
                .method_46434(bx + btnW + gap, buttonY, btnW, 20).method_46431();
        cancelButton = class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
                .method_46434(bx + (btnW + gap) * 2, buttonY, btnW, 20).method_46431();

        method_37063(submitButton);
        method_37063(clearButton);
        method_37063(cancelButton);
    }

    private void focusLine(int index) {
        if (index < 0 || index >= lines.size()) return;
        for (class_342 f : lines) f.method_25365(false);
        lines.get(index).method_25365(true);
        method_25395(lines.get(index));
    }

    private void onSubmit() {
        StringBuilder sb = new StringBuilder();
        for (class_342 f : lines) {
            String t = f.method_1882().trim();
            if (!t.isEmpty()) {
                if (sb.length() > 0) sb.append(" ");
                sb.append(t);
            }
        }
        String prompt = sb.toString().trim();

        if (postRecording) {
            String recName = (nameField != null && !nameField.method_1882().isBlank())
                    ? nameField.method_1882().trim()
                    : "recording_" + System.currentTimeMillis();

            if (recorder != null) {
                recorder.save(recName);
            }

            if (!prompt.isEmpty()) {
                promptExecutor.executeAndSave(prompt, null);
            }

            method_25419();
            return;
        }

        if (prompt.isEmpty()) {
            statusText = "Write what you want the AI to do first.";
            return;
        }

        promptExecutor.executePrompt(prompt);
        method_25419();
    }

    private void onClear() {
        for (class_342 f : lines) f.method_1852("");
        if (nameField != null) nameField.method_1852("");
        statusText = "";
        if (postRecording && nameField != null) {
            method_25395(nameField);
            nameField.method_25365(true);
        } else {
            focusLine(0);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);

        int panelWidth = Math.min(field_22789 - PADDING * 2, 600);
        int panelX = (field_22789 - panelWidth) / 2;
        int nameExtra = postRecording ? FIELD_SPACING + 6 : 0;
        int promptStartY = PADDING + 42 + nameExtra;
        int panelTop = PADDING - 6;
        int panelBottom = promptStartY + MAX_LINES * FIELD_SPACING + 42;

        context.method_25294(panelX - 6, panelTop, panelX + panelWidth + 6, panelBottom, 0xBB000000);
        context.method_25294(panelX - 5, panelTop + 1, panelX + panelWidth + 5, panelBottom - 1, 0xFF1A1A2E);

        String title = postRecording
                ? "\u00A7bSave Recording \u2014 Name it & describe behaviour"
                : "\u00A7bAI Prompt \u2014 Describe what to do";
        context.method_27534(field_22793, class_2561.method_43470(title), field_22789 / 2, PADDING + 6, 0xFFFFFF);

        String hint = postRecording
                ? "\u00A77Tab to move to prompt, Enter to save. Prompt is optional."
                : "\u00A77Lines are joined and sent as one prompt to the AI";
        context.method_27534(field_22793, class_2561.method_43470(hint), field_22789 / 2, PADDING + 18, 0xAAAAAA);

        if (postRecording) {
            context.method_27535(field_22793, class_2561.method_43470("\u00A7eName:"),
                    panelX, PADDING + 42 - 10, 0xFFFFFF);
        }

        super.method_25394(context, mouseX, mouseY, delta);

        if (!statusText.isEmpty()) {
            context.method_25300(field_22793, statusText, field_22789 / 2, panelBottom - 14, 0x55FF55);
        }
    }

    @Override
    public boolean method_25421() { return false; }

    @Override
    public boolean method_25422() { return true; }
}
