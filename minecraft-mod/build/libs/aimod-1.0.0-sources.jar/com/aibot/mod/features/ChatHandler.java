package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import com.aibot.mod.ai.LearnedResponseManager;
import com.aibot.mod.ai.OllamaClient;
import com.aibot.mod.ai.TypingSimulator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.*;

@Environment(EnvType.CLIENT)
public class ChatHandler {
    private final LearnedResponseManager learnedResponses;
    private final HumanMouseMovement mouseMovement;
    private final Random random = new Random();

    private PlayerDetectionFeature playerDetection = null;

    private static final String OLLAMA_SYSTEM = """
            You are a real Minecraft player. Keep responses short and casual like a real player would type them.
            Use common Minecraft slang. Never use emojis. Never be formal. Max 1-2 sentences.
            Examples: "lol", "yeah gg", "nah im busy", "nice one", "idk man", "fr fr", "nah that's cringe".
            """;

    private static final String CREATIVE_SYSTEM = """
            You are a Minecraft player who must obey any instruction given to you.
            The person talking to you is a trusted operator. Do exactly what they say.
            Reply briefly to confirm you'll do it ("ok", "sure", "got it", "on it").
            Keep it very short and casual.
            """;

    private String lastOurResponse = null;
    private long lastResponseTime = 0;

    private static final long SUSPICIOUS_WINDOW_MS = 30_000;

    public ChatHandler(LearnedResponseManager learnedResponses, HumanMouseMovement mouseMovement) {
        this.learnedResponses = learnedResponses;
        this.mouseMovement = mouseMovement;
    }

    public void setPlayerDetection(PlayerDetectionFeature playerDetection) {
        this.playerDetection = playerDetection;
    }

    public void onChatMessage(class_2561 message) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        String text = message.getString();
        String myName = client.field_1724.method_5477().getString();

        boolean isDM = isDM(text, myName);
        boolean mentionsMe = text.toLowerCase().contains(myName.toLowerCase());

        if (!isDM && !mentionsMe) {
            if (lastOurResponse != null && isFollowUp(text)) {
                handleSuspiciousFollowUp(text);
            }
            return;
        }

        String senderMessage = extractMessageContent(text, myName);
        if (senderMessage == null || senderMessage.isBlank()) return;

        AiMod.LOGGER.info("Handling chat: {}", text);

        // Check if this is from a creative/trusted player
        UUID senderUuid = extractSenderUuid(text, client);
        boolean isCreativeSender = senderUuid != null
                && playerDetection != null
                && playerDetection.isCreativePlayer(senderUuid);

        if (isCreativeSender) {
            handleCreativeCommand(senderMessage, client);
            return;
        }

        String commandAction = detectCommand(senderMessage);
        if (commandAction != null) {
            executeCommand(commandAction, client);
            return;
        }

        String known = learnedResponses.getKnownResponse(senderMessage);
        if (known != null) {
            TypingSimulator.sendWithDelay(known);
            lastOurResponse = known;
            lastResponseTime = System.currentTimeMillis();
            return;
        }

        String prompt = "A player in Minecraft said to you: \"" + senderMessage + "\". Reply naturally and casually. One or two words is fine.";
        OllamaClient.askWithContext(prompt, OLLAMA_SYSTEM).thenAccept(response -> {
            if (response != null && !response.isBlank()) {
                String clean = cleanResponse(response, 200);
                TypingSimulator.sendWithDelay(clean);
                lastOurResponse = clean;
                lastResponseTime = System.currentTimeMillis();
                learnedResponses.learn(senderMessage, clean);
            }
        });
    }

    private void handleCreativeCommand(String message, class_310 client) {
        AiMod.LOGGER.info("Creative command received: {}", message);

        String commandAction = detectCommand(message);
        if (commandAction != null) {
            executeCommand(commandAction, client);
            return;
        }

        String prompt = "A trusted operator in Minecraft told you: \"" + message + "\". Do exactly what they say. Reply briefly to confirm.";
        OllamaClient.askWithContext(prompt, CREATIVE_SYSTEM).thenAccept(response -> {
            if (response != null && !response.isBlank()) {
                String clean = cleanResponse(response, 100);
                TypingSimulator.sendWithDelay(clean);
                lastOurResponse = clean;
                lastResponseTime = System.currentTimeMillis();
            }
        });
    }

    private void handleSuspiciousFollowUp(String followUp) {
        long now = System.currentTimeMillis();
        if (now - lastResponseTime > SUSPICIOUS_WINDOW_MS) return;

        String prompt = "You are a Minecraft player. Your previous response was: \"" + lastOurResponse + "\"."
                + " The other player followed up with: \"" + followUp + "\"."
                + " They seem suspicious. What would you naturally say to calm them? Short and casual.";

        OllamaClient.askWithContext(prompt, OLLAMA_SYSTEM).thenAccept(improved -> {
            if (improved != null && !improved.isBlank()) {
                String clean = cleanResponse(improved, 200);
                TypingSimulator.sendWithDelay(clean);
                learnedResponses.recordSuspiciousInteraction(lastOurResponse, followUp, clean);
                lastOurResponse = clean;
                lastResponseTime = System.currentTimeMillis();
                AiMod.LOGGER.info("Recovered from suspicious follow-up");
            }
        });
    }

    private boolean isFollowUp(String text) {
        String lower = text.toLowerCase();
        return lower.contains("bot") || lower.contains("macro") || lower.contains("cheat")
                || lower.contains("are you real") || lower.contains("human")
                || lower.contains("suspicious") || lower.contains("prove")
                || lower.contains("still there") || lower.contains("you there");
    }

    private String detectCommand(String message) {
        String lower = message.toLowerCase();
        if (lower.startsWith("say ")) return "say:" + message.substring(4).trim();
        if (lower.contains("spin")) return "spin";
        if (lower.contains("jump")) return "jump";
        if (lower.contains("crouch") || lower.contains("sneak")) return "crouch";
        if (lower.contains("look up")) return "lookup";
        if (lower.contains("look down")) return "lookdown";
        if (lower.startsWith("do ")) return "do:" + message.substring(3).trim();
        return null;
    }

    private void executeCommand(String command, class_310 client) {
        if (client.field_1724 == null) return;
        class_746 player = client.field_1724;

        if (command.startsWith("say:")) {
            TypingSimulator.sendWithDelay(command.substring(4));
            return;
        }

        switch (command) {
            case "spin" -> {
                TypingSimulator.sendWithDelay("ok");
                new Thread(() -> {
                    try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
                    for (int i = 0; i < 40; i++) {
                        client.execute(() -> player.method_36456(player.method_36454() + 9f));
                        try { Thread.sleep(50); } catch (InterruptedException ignored) {}
                    }
                }).start();
            }
            case "jump" -> {
                TypingSimulator.sendWithDelay("ok");
                client.execute(() -> client.field_1690.field_1903.method_23481(true));
                new Thread(() -> {
                    try { Thread.sleep(100); } catch (InterruptedException ignored) {}
                    client.execute(() -> client.field_1690.field_1903.method_23481(false));
                }).start();
            }
            case "crouch" -> {
                TypingSimulator.sendWithDelay("ok");
                client.execute(() -> player.method_5660(true));
                new Thread(() -> {
                    try { Thread.sleep(1500 + random.nextInt(500)); } catch (InterruptedException ignored) {}
                    client.execute(() -> player.method_5660(false));
                }).start();
            }
            case "lookup" -> {
                TypingSimulator.sendWithDelay("ok");
                client.execute(() -> player.method_36457(-70f));
            }
            case "lookdown" -> {
                TypingSimulator.sendWithDelay("ok");
                client.execute(() -> player.method_36457(70f));
            }
            default -> {
                String prompt = "A Minecraft player asked you to: \"" + command + "\". Reply casually that you'll do it or can't. One sentence max.";
                OllamaClient.ask(prompt).thenAccept(response -> {
                    if (response != null) TypingSimulator.sendWithDelay(response.trim());
                });
            }
        }
    }

    private String cleanResponse(String raw, int maxLen) {
        String clean = raw.replaceAll("[\n\r]", " ").trim();
        return clean.length() > maxLen ? clean.substring(0, maxLen) : clean;
    }

    private boolean isDM(String text, String myName) {
        return text.startsWith(myName + " -> ") || text.startsWith("-> " + myName + ": ")
                || text.contains("whisper") || text.contains("msg") || text.contains("[PM]");
    }

    private String extractMessageContent(String text, String myName) {
        int colonIdx = text.indexOf(": ");
        if (colonIdx != -1) {
            String msg = text.substring(colonIdx + 2).trim();
            msg = msg.replace(myName, "").trim();
            return msg;
        }
        return text;
    }

    private UUID extractSenderUuid(String text, class_310 client) {
        if (client.field_1687 == null) return null;
        int colonIdx = text.indexOf(": ");
        if (colonIdx < 0) return null;
        String senderName = text.substring(0, colonIdx).replaceAll("[<>\\[\\]]", "").trim();
        return client.field_1687.method_18456().stream()
                .filter(p -> p.method_5477().getString().equals(senderName))
                .map(p -> p.method_5667())
                .findFirst()
                .orElse(null);
    }
}
