package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import com.aibot.mod.ai.LearnedResponseManager;
import com.aibot.mod.ai.OllamaClient;
import com.aibot.mod.gui.PromptScreen;
import com.aibot.mod.gui.RecordingManagerScreen;
import com.aibot.mod.keybind.ModKeyBindings;
import com.aibot.mod.macro.AiPromptExecutor;
import com.aibot.mod.macro.MovementPlayback;
import com.aibot.mod.macro.MovementRecorder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public class FeatureManager {
    private final AutoFishFeature autoFish = new AutoFishFeature();
    private final AutoAttackFeature autoAttack = new AutoAttackFeature();
    private final AutoSellFeature autoSell = new AutoSellFeature();
    private final PlayerDetectionFeature playerDetection = new PlayerDetectionFeature();
    private final HumanMouseMovement mouseMovement = new HumanMouseMovement();
    private final LearnedResponseManager learnedResponses = new LearnedResponseManager();
    private final CaptchaSolver captchaSolver = new CaptchaSolver();
    private final MovementRecorder recorder = new MovementRecorder();
    private final MovementPlayback playback = new MovementPlayback();
    private final AiPromptExecutor promptExecutor;
    private ChatHandler chatHandler;

    private boolean allActive = false;

    public FeatureManager() {
        promptExecutor = new AiPromptExecutor(playback);
    }

    public void init() {
        learnedResponses.load();
        chatHandler = new ChatHandler(learnedResponses, mouseMovement);
        chatHandler.setPlayerDetection(playerDetection);

        playerDetection.setPlayback(playback);
        promptExecutor.setRecorder(recorder);

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
        ClientReceiveMessageEvents.GAME.register(this::onGameMessage);
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) ->
                onChatMessage(message));

        OllamaClient.isAvailable();
        AiMod.LOGGER.info("Feature manager initialized.");
    }

    private void onClientTick(class_310 client) {
        if (client.field_1724 == null) return;

        handleKeyBindings(client);

        if (autoFish.isActive()) autoFish.tick();
        if (autoAttack.isActive()) autoAttack.tick();
        autoSell.tick();
        playerDetection.tick();
        recorder.tick();
        playback.tick();
    }

    private void handleKeyBindings(class_310 client) {
        while (ModKeyBindings.toggleFish.method_1436()) {
            boolean newState = !autoFish.isActive();
            autoFish.setActive(newState);
            sendActionBar(client, "Auto-Fish: " + (newState ? "ON" : "OFF"));
        }

        while (ModKeyBindings.toggleAttack.method_1436()) {
            boolean newState = !autoAttack.isActive();
            autoAttack.setActive(newState);
            sendActionBar(client, "Auto-Attack: " + (newState ? "ON" : "OFF"));
        }

        while (ModKeyBindings.toggleAll.method_1436()) {
            allActive = !allActive;
            autoFish.setActive(allActive);
            autoAttack.setActive(allActive);
            autoSell.setActive(allActive);
            sendActionBar(client, "AI Mod: " + (allActive ? "ALL ON" : "ALL OFF"));
        }

        while (ModKeyBindings.toggleRecord.method_1436()) {
            if (recorder.isRecording()) {
                recorder.stopRecording();
                // Auto-open prompt screen to name and describe the recording
                if (client.field_1755 == null) {
                    client.method_1507(new PromptScreen(promptExecutor, recorder, true));
                }
            } else {
                if (playback.isPlaying()) playback.stop();
                recorder.startRecording("last");
            }
        }

        while (ModKeyBindings.togglePlayback.method_1436()) {
            if (playback.isPlaying() || playback.isScanning()) {
                playback.stop();
                playback.stopScan();
            } else {
                var frames = recorder.load("last");
                if (frames != null && !frames.isEmpty()) {
                    playback.setMouseLocked(false);
                    playback.start(frames, true);
                } else {
                    sendActionBar(client, "No recording found. Press [R] to record first.");
                }
            }
        }

        while (ModKeyBindings.openPromptGui.method_1436()) {
            if (client.field_1755 == null) {
                client.method_1507(new PromptScreen(promptExecutor));
            }
        }

        while (ModKeyBindings.openRecordingManager.method_1436()) {
            if (client.field_1755 == null) {
                client.method_1507(new RecordingManagerScreen(recorder, playback));
            }
        }
    }

    private void onGameMessage(class_2561 message, boolean overlay) {
        if (overlay) return;
        captchaSolver.handleChatCaptcha(message);
        chatHandler.onChatMessage(message);
    }

    private void onChatMessage(class_2561 message) {
        captchaSolver.handleChatCaptcha(message);
        chatHandler.onChatMessage(message);
    }

    private void sendActionBar(class_310 client, String msg) {
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[AI] " + msg), true);
        }
    }

    public AutoFishFeature getAutoFish() { return autoFish; }
    public AutoAttackFeature getAutoAttack() { return autoAttack; }
    public AutoSellFeature getAutoSell() { return autoSell; }
    public LearnedResponseManager getLearnedResponses() { return learnedResponses; }
    public MovementRecorder getRecorder() { return recorder; }
    public MovementPlayback getPlayback() { return playback; }
    public AiPromptExecutor getPromptExecutor() { return promptExecutor; }
}
