package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import com.aibot.mod.ai.TypingSimulator;
import com.aibot.mod.config.ModConfig;
import com.aibot.mod.macro.MovementPlayback;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.*;

@Environment(EnvType.CLIENT)
public class PlayerDetectionFeature {
    private final HumanMouseMovement mouseMovement = new HumanMouseMovement();
    private final Set<UUID> greetedPlayers = new HashSet<>();
    private final Set<UUID> creativePlayers = new HashSet<>();
    private final Random random = new Random();

    private MovementPlayback playback = null;

    private class_1657 nearestPlayer = null;
    private boolean playerWasNear = false;
    private int greetCooldown = 0;
    private int lookAtPlayerTimer = 0;
    private boolean lookingAtPlayer = false;
    private int crouchTimer = 0;
    private boolean hasCrouched = false;

    private static final String[] CASUAL_GREETINGS = {
        "yo", "hey", "sup", "oh hey", "lol hi", "hi", "hey man"
    };

    public void setPlayback(MovementPlayback playback) {
        this.playback = playback;
    }

    public void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_746 self = client.field_1724;

        if (greetCooldown > 0) greetCooldown--;

        if (crouchTimer > 0) {
            crouchTimer--;
            if (crouchTimer == 0) {
                self.method_5660(false);
                hasCrouched = true;
            }
        }

        nearestPlayer = findNearestOtherPlayer(client, self);
        boolean playerIsNear = nearestPlayer != null;

        if (playerIsNear && !playerWasNear) {
            onPlayerEnter(client, self, nearestPlayer);
        } else if (!playerIsNear && playerWasNear) {
            onPlayerLeave(client);
        }

        playerWasNear = playerIsNear;

        if (lookingAtPlayer && nearestPlayer != null) {
            lookAtPlayerTimer--;
            mouseMovement.setTarget(nearestPlayer);
            mouseMovement.tick();

            if (!hasCrouched && lookAtPlayerTimer < 40) {
                self.method_5660(true);
                crouchTimer = 15 + random.nextInt(10);
            }

            if (lookAtPlayerTimer <= 0) {
                lookingAtPlayer = false;
                hasCrouched = false;
                mouseMovement.clearTarget();
            }
        }
    }

    private void onPlayerEnter(class_310 client, class_746 self, class_1657 player) {
        AiMod.LOGGER.info("Player entered range: {}", player.method_5477().getString());

        if (playback != null && playback.isPlaying()) {
            playback.pause();
            AiMod.LOGGER.info("Playback paused — player nearby");
        }

        boolean isCreative = player.method_31549().field_7477;
        if (isCreative) {
            creativePlayers.add(player.method_5667());
            AiMod.LOGGER.info("Player {} is creative — will obey commands", player.method_5477().getString());
        }

        if (!greetedPlayers.contains(player.method_5667()) && greetCooldown <= 0) {
            greetPlayer(player);
            greetedPlayers.add(player.method_5667());
            greetCooldown = 600;
        } else {
            lookingAtPlayer = true;
            lookAtPlayerTimer = 50 + random.nextInt(30);
            hasCrouched = false;
        }
    }

    private void onPlayerLeave(class_310 client) {
        AiMod.LOGGER.info("Player left range — will resume playback");
        lookingAtPlayer = false;
        mouseMovement.clearTarget();

        if (playback != null && playback.isPaused()) {
            int delayMs = (60 + random.nextInt(80)) * 50;
            new Thread(() -> {
                try { Thread.sleep(delayMs); } catch (InterruptedException ignored) {}
                client.execute(() -> {
                    if (playback.isPaused()) {
                        playback.resume();
                        AiMod.LOGGER.info("Playback resumed after player left");
                    }
                });
            }).start();
        }
    }

    private void greetPlayer(class_1657 target) {
        lookingAtPlayer = true;
        lookAtPlayerTimer = 80 + random.nextInt(40);
        hasCrouched = false;

        String greeting = CASUAL_GREETINGS[random.nextInt(CASUAL_GREETINGS.length)];
        TypingSimulator.sendWithDelay(greeting);

        AiMod.LOGGER.info("Greeted player: {}", target.method_5477().getString());
    }

    private class_1657 findNearestOtherPlayer(class_310 client, class_746 self) {
        class_238 searchBox = self.method_5829().method_1014(ModConfig.playerDetectionRange);
        List<class_1657> players = client.field_1687.method_8390(
                class_1657.class,
                searchBox,
                p -> p != self && p.method_5805()
        );
        return players.stream()
                .min(Comparator.comparingDouble(p -> p.method_5858(self)))
                .orElse(null);
    }

    public boolean isCreativePlayer(UUID uuid) {
        return creativePlayers.contains(uuid);
    }

    public void forgetPlayer(UUID uuid) {
        greetedPlayers.remove(uuid);
        creativePlayers.remove(uuid);
    }

    public class_1657 getNearestPlayer() {
        return nearestPlayer;
    }
}
