package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1536;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class AutoFishFeature {
    private boolean active = false;
    private final HumanMouseMovement mouseMovement = new HumanMouseMovement();
    private final Random random = new Random();

    private int castCooldown = 0;
    private int hookCheckTimer = 0;
    private boolean waitingForBite = false;
    private int noWaterWarnTimer = 0;

    public void setActive(boolean active) {
        this.active = active;
        if (!active) {
            waitingForBite = false;
            castCooldown = 0;
        } else {
            AiMod.LOGGER.info("Auto-fish enabled");
        }
    }

    public boolean isActive() {
        return active;
    }

    public void tick() {
        if (!active) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_746 player = client.field_1724;

        if (!isHoldingFishingRod(player)) return;

        if (!isNearWater(client, player)) {
            noWaterWarnTimer++;
            if (noWaterWarnTimer % 100 == 0) {
                player.method_7353(
                    net.minecraft.class_2561.method_43470("[AI] No water nearby - stand next to water to fish!"), true
                );
            }
            return;
        }
        noWaterWarnTimer = 0;

        mouseMovement.jitter();

        if (castCooldown > 0) {
            castCooldown--;
            return;
        }

        class_1536 bobber = player.field_7513;

        if (bobber == null) {
            if (!waitingForBite) {
                lookTowardWater(client, player);
                cast(client, player);
                waitingForBite = true;
                hookCheckTimer = 0;
            }
            return;
        }

        hookCheckTimer++;

        if (hookCheckTimer > 20) {
            if (hasFishOnHook(bobber)) {
                reelIn(client, player);
                waitingForBite = false;
                castCooldown = 10 + random.nextInt(15);
            }
        }

        if (hookCheckTimer > 400 + random.nextInt(100)) {
            reelIn(client, player);
            waitingForBite = false;
            castCooldown = 5 + random.nextInt(10);
        }
    }

    private boolean isNearWater(class_310 client, class_746 player) {
        class_2338 playerPos = player.method_24515();
        int searchRadius = 5;
        for (int x = -searchRadius; x <= searchRadius; x++) {
            for (int y = -2; y <= 1; y++) {
                for (int z = -searchRadius; z <= searchRadius; z++) {
                    class_2338 pos = playerPos.method_10069(x, y, z);
                    var block = client.field_1687.method_8320(pos).method_26204();
                    if (block == class_2246.field_10382) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void lookTowardWater(class_310 client, class_746 player) {
        class_2338 playerPos = player.method_24515();
        int searchRadius = 5;
        for (int x = -searchRadius; x <= searchRadius; x++) {
            for (int z = -searchRadius; z <= searchRadius; z++) {
                class_2338 pos = playerPos.method_10069(x, -1, z);
                var block = client.field_1687.method_8320(pos).method_26204();
                if (block == class_2246.field_10382) {
                    float yaw = (float) Math.toDegrees(Math.atan2(-x, z));
                    player.method_36456(yaw);
                    player.method_36457(25f + random.nextFloat() * 15f);
                    return;
                }
            }
        }
    }

    private void cast(class_310 client, class_746 player) {
        client.field_1761.method_2919(player, class_1268.field_5808);
    }

    private void reelIn(class_310 client, class_746 player) {
        client.field_1761.method_2919(player, class_1268.field_5808);
    }

    private boolean hasFishOnHook(class_1536 bobber) {
        return bobber.method_26957() != null || bobber.method_5869();
    }

    private boolean isHoldingFishingRod(class_746 player) {
        class_1799 mainHand = player.method_6047();
        class_1799 offHand = player.method_6079();
        return mainHand.method_7909() instanceof class_1787
                || offHand.method_7909() instanceof class_1787;
    }
}
