package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1536;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class AutoFishFeature {
    private boolean active = false;
    private final HumanMouseMovement mouseMovement = new HumanMouseMovement();
    private final Random random = new Random();

    private int castCooldown = 0;
    private int hookCheckTimer = 0;
    private boolean waitingForBite = false;
    private int noWaterWarnTimer = 0;

    // Anti-AFK behaviour while waiting
    private int idleBehaviourTimer = 0;
    private int idlePhase = 0;

    // Bobber position tracking for motion-based bite detection
    private double lastBobberY = Double.NaN;
    private double prevBobberY = Double.NaN;
    private int motionSampleTimer = 0;

    // Rod durability warning
    private int lastKnownDurability = -1;

    public void setActive(boolean active) {
        this.active = active;
        if (!active) {
            waitingForBite = false;
            castCooldown = 0;
            idleBehaviourTimer = 0;
            lastBobberY = Double.NaN;
        } else {
            AiMod.LOGGER.info("Auto-fish enabled");
        }
    }

    public boolean isActive() { return active; }

    public void tick() {
        if (!active) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_746 player = client.field_1724;

        if (!isHoldingFishingRod(player)) {
            player.method_7353(
                net.minecraft.class_2561.method_43470("[AI] No fishing rod in hand — equip one to fish!"), true);
            return;
        }

        checkRodDurability(player);

        if (!isNearWater(client, player)) {
            noWaterWarnTimer++;
            if (noWaterWarnTimer % 120 == 0) {
                player.method_7353(
                    net.minecraft.class_2561.method_43470("[AI] No water nearby — move next to water!"), true);
            }
            return;
        }
        noWaterWarnTimer = 0;

        // Subtle idle movements while waiting for a bite (looks more human)
        tickIdleBehaviour(client, player);

        if (castCooldown > 0) {
            castCooldown--;
            return;
        }

        class_1536 bobber = player.field_7513;

        if (bobber == null) {
            if (!waitingForBite) {
                lookTowardWater(client, player);
                cast(client, player);
                waitingForBite = true;
                hookCheckTimer = 0;
                lastBobberY = Double.NaN;
                prevBobberY = Double.NaN;
                motionSampleTimer = 0;
            }
            return;
        }

        hookCheckTimer++;

        // Track bobber Y position for motion-based bite detection
        if (hookCheckTimer > 15) {
            trackBobberMotion(bobber);

            if (hasBiteByMotion()) {
                AiMod.LOGGER.info("Bite detected via bobber motion!");
                reelIn(client, player);
                waitingForBite = false;
                // Randomise cast cooldown to vary the rhythm
                castCooldown = 8 + random.nextInt(20);
                lastBobberY = Double.NaN;
                return;
            }

            // Fallback: entity hook check
            if (hasFishOnHook(bobber)) {
                reelIn(client, player);
                waitingForBite = false;
                castCooldown = 8 + random.nextInt(18);
                lastBobberY = Double.NaN;
                return;
            }
        }

        // Timeout: reel in if bobber has been out too long (vary this to avoid pattern)
        int timeout = 380 + random.nextInt(120);
        if (hookCheckTimer > timeout) {
            reelIn(client, player);
            waitingForBite = false;
            castCooldown = 4 + random.nextInt(12);
            lastBobberY = Double.NaN;
        }
    }

    private void trackBobberMotion(class_1536 bobber) {
        motionSampleTimer++;
        if (motionSampleTimer % 2 != 0) return;

        prevBobberY = lastBobberY;
        lastBobberY = bobber.method_23318();
    }

    private boolean hasBiteByMotion() {
        if (Double.isNaN(prevBobberY) || Double.isNaN(lastBobberY)) return false;
        double drop = prevBobberY - lastBobberY;
        // A fish bite causes the bobber to dip down sharply
        return drop > 0.06;
    }

    private void tickIdleBehaviour(class_310 client, class_746 player) {
        idleBehaviourTimer--;
        if (idleBehaviourTimer > 0) return;

        // Rotate through different idle behaviours
        idlePhase = (idlePhase + 1) % 4;
        switch (idlePhase) {
            case 0 -> {
                // Gentle yaw adjustment, looking slightly around
                float offsetYaw = (random.nextFloat() - 0.5f) * 8f;
                mouseMovement.setTargetAngles(player.method_36454() + offsetYaw,
                        22f + random.nextFloat() * 12f);
                idleBehaviourTimer = 40 + random.nextInt(60);
            }
            case 1 -> {
                // Micro head-jitter (already handled by mouseMovement.jitter)
                mouseMovement.jitter();
                idleBehaviourTimer = 20 + random.nextInt(30);
            }
            case 2 -> {
                // Occasionally glance down at inventory (look down briefly)
                if (random.nextFloat() < 0.3f) {
                    client.execute(() -> player.method_36457(55f + random.nextFloat() * 15f));
                }
                idleBehaviourTimer = 30 + random.nextInt(50);
            }
            case 3 -> {
                // Reset to looking at water
                lookTowardWater(client, player);
                idleBehaviourTimer = 60 + random.nextInt(80);
            }
        }
    }

    private boolean isNearWater(class_310 client, class_746 player) {
        class_2338 playerPos = player.method_24515();
        int searchRadius = 6;
        for (int x = -searchRadius; x <= searchRadius; x++) {
            for (int y = -2; y <= 1; y++) {
                for (int z = -searchRadius; z <= searchRadius; z++) {
                    class_2338 pos = playerPos.method_10069(x, y, z);
                    var block = client.field_1687.method_8320(pos).method_26204();
                    if (block == class_2246.field_10382) return true;
                }
            }
        }
        return false;
    }

    private void lookTowardWater(class_310 client, class_746 player) {
        class_2338 playerPos = player.method_24515();
        int searchRadius = 6;

        class_2338 bestWater = null;
        double bestDist = Double.MAX_VALUE;

        for (int x = -searchRadius; x <= searchRadius; x++) {
            for (int z = -searchRadius; z <= searchRadius; z++) {
                for (int y = -1; y >= -3; y--) {
                    class_2338 pos = playerPos.method_10069(x, y, z);
                    if (client.field_1687.method_8320(pos).method_26204() == class_2246.field_10382) {
                        double dist = x * x + z * z;
                        if (dist < bestDist) {
                            bestDist = dist;
                            bestWater = pos;
                        }
                        break;
                    }
                }
            }
        }

        if (bestWater != null) {
            int dx = bestWater.method_10263() - playerPos.method_10263();
            int dz = bestWater.method_10260() - playerPos.method_10260();
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            // Add small random offset so it doesn't look perfectly aimed
            yaw += (random.nextFloat() - 0.5f) * 6f;
            player.method_36456(yaw);
            player.method_36457(22f + random.nextFloat() * 14f);
        }
    }

    private void cast(class_310 client, class_746 player) {
        client.field_1761.method_2919(player, class_1268.field_5808);
        AiMod.LOGGER.debug("Cast fishing rod");
    }

    private void reelIn(class_310 client, class_746 player) {
        client.field_1761.method_2919(player, class_1268.field_5808);
        AiMod.LOGGER.debug("Reeled in fishing rod");
    }

    private boolean hasFishOnHook(class_1536 bobber) {
        return bobber.method_26957() != null || bobber.method_5869();
    }

    private boolean isHoldingFishingRod(class_746 player) {
        class_1799 mainHand = player.method_6047();
        class_1799 offHand = player.method_6079();
        return mainHand.method_7909() instanceof class_1787
                || offHand.method_7909() instanceof class_1787;
    }

    private void checkRodDurability(class_746 player) {
        class_1799 rod = player.method_6047();
        if (!(rod.method_7909() instanceof class_1787)) {
            rod = player.method_6079();
        }
        if (!(rod.method_7909() instanceof class_1787)) return;

        int maxDurability = rod.method_7936();
        int currentDamage = rod.method_7919();
        int remaining = maxDurability - currentDamage;

        if (lastKnownDurability != remaining) {
            lastKnownDurability = remaining;
            if (remaining > 0 && remaining <= 20) {
                player.method_7353(
                    net.minecraft.class_2561.method_43470("[AI] Warning: Fishing rod almost broken! (" + remaining + " uses left)"), true);
            }
        }
    }
}
