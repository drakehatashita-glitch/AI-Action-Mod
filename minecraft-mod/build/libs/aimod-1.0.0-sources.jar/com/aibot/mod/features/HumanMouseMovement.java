package com.aibot.mod.features;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class HumanMouseMovement {
    private static final Random RANDOM = new Random();

    private float targetYaw;
    private float targetPitch;
    private boolean hasTarget = false;
    private float smoothSpeed = 3.5f;

    public void setTarget(class_1297 entity) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_243 playerEyes = client.field_1724.method_33571();
        class_243 entityCenter = entity.method_5829().method_1005();
        class_243 diff = entityCenter.method_1020(playerEyes);

        double horizontalDist = Math.sqrt(diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350);
        targetYaw = (float) (Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350)));
        targetPitch = (float) (-Math.toDegrees(Math.atan2(diff.field_1351, horizontalDist)));

        targetYaw += (RANDOM.nextFloat() - 0.5f) * 2.5f;
        targetPitch += (RANDOM.nextFloat() - 0.5f) * 1.5f;

        hasTarget = true;
    }

    public void setTargetAngles(float yaw, float pitch) {
        targetYaw = yaw;
        targetPitch = pitch;
        hasTarget = true;
    }

    public void clearTarget() {
        hasTarget = false;
    }

    public boolean hasTarget() {
        return hasTarget;
    }

    public boolean tick() {
        if (!hasTarget) return false;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return false;

        class_746 player = client.field_1724;
        float currentYaw = player.method_36454();
        float currentPitch = player.method_36455();

        float yawDiff = wrapAngle(targetYaw - currentYaw);
        float pitchDiff = targetPitch - currentPitch;

        float speed = smoothSpeed + RANDOM.nextFloat() * 1.5f;
        float moveFraction = 1.0f / speed;

        float newYaw = currentYaw + yawDiff * moveFraction;
        float newPitch = currentPitch + pitchDiff * moveFraction;

        newPitch = Math.max(-90f, Math.min(90f, newPitch));

        player.method_36456(newYaw);
        player.method_36457(newPitch);

        return Math.abs(yawDiff) < 2.0f && Math.abs(pitchDiff) < 2.0f;
    }

    public void jitter() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;
        float jitterYaw = (RANDOM.nextFloat() - 0.5f) * 0.6f;
        float jitterPitch = (RANDOM.nextFloat() - 0.5f) * 0.3f;

        if (RANDOM.nextInt(4) != 0) return;

        player.method_36456(player.method_36454() + jitterYaw);
        player.method_36457(Math.max(-90f, Math.min(90f, player.method_36455() + jitterPitch)));
    }

    private float wrapAngle(float angle) {
        while (angle > 180f) angle -= 360f;
        while (angle < -180f) angle += 360f;
        return angle;
    }
}
