package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import com.aibot.mod.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class AutoAttackFeature {
    private boolean active = false;
    private final HumanMouseMovement mouseMovement = new HumanMouseMovement();
    private final Random random = new Random();

    private class_1309 currentTarget = null;
    private int attackCooldown = 0;
    private int crouchTimer = 0;
    private boolean isCrouching = false;
    private class_243 lastPlayerPos = null;
    private int repositionCooldown = 0;

    public void setActive(boolean active) {
        this.active = active;
        if (!active) {
            currentTarget = null;
            mouseMovement.clearTarget();
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null) {
                client.field_1724.method_5660(false);
            }
        } else {
            AiMod.LOGGER.info("Auto-attack enabled");
        }
    }

    public boolean isActive() {
        return active;
    }

    public void tick() {
        if (!active) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_746 player = client.field_1724;

        if (crouchTimer > 0) {
            crouchTimer--;
            if (crouchTimer == 0) {
                player.method_5660(false);
                isCrouching = false;
            }
            return;
        }

        if (repositionCooldown > 0) {
            repositionCooldown--;
        }

        currentTarget = findNearestHostile(client, player);

        if (currentTarget == null || !currentTarget.method_5805()) {
            currentTarget = null;
            mouseMovement.clearTarget();
            lastPlayerPos = null;
            return;
        }

        mouseMovement.setTarget(currentTarget);
        boolean lookingAt = mouseMovement.tick();

        double distToTarget = player.method_5739(currentTarget);

        if (distToTarget > ModConfig.attackRange + 1.5) {
            moveTowardTarget(client, player);
        }

        if (attackCooldown > 0) {
            attackCooldown--;
        }

        if (lookingAt && attackCooldown <= 0 && distToTarget <= ModConfig.attackRange) {
            client.field_1761.method_2918(player, currentTarget);
            attackCooldown = 10 + random.nextInt(4);
        }

        lastPlayerPos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
    }

    public void onDisplacedByPlayer() {
        if (!active) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || currentTarget == null) return;

        class_746 player = client.field_1724;

        player.method_5660(true);
        isCrouching = true;
        crouchTimer = 15 + random.nextInt(10);

        if (currentTarget != null) {
            mouseMovement.setTarget(currentTarget);
        }

        repositionCooldown = 20;
    }

    private void moveTowardTarget(class_310 client, class_746 player) {
        class_243 playerPos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
        class_243 targetPos = new class_243(currentTarget.method_23317(), currentTarget.method_23318(), currentTarget.method_23321());
        class_243 dir = targetPos.method_1020(playerPos).method_1029();

        float targetYaw = (float) Math.toDegrees(Math.atan2(-dir.field_1352, dir.field_1350));
        mouseMovement.setTargetAngles(targetYaw, player.method_36455());

        client.field_1690.field_1894.method_23481(true);
    }

    private class_1309 findNearestHostile(class_310 client, class_746 player) {
        class_238 searchBox = player.method_5829().method_1014(ModConfig.attackRange + 4.0);
        List<class_1309> hostiles = client.field_1687.method_8390(
                class_1309.class,
                searchBox,
                e -> e instanceof class_1588 && e.method_5805() && e != player
        );

        return hostiles.stream()
                .min(Comparator.comparingDouble(e -> e.method_5858(player)))
                .orElse(null);
    }
}
