package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import com.aibot.mod.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class AutoAttackFeature {
    private boolean active = false;
    private final HumanMouseMovement mouseMovement = new HumanMouseMovement();
    private final Random random = new Random();

    private class_1309 currentTarget = null;
    private int attackCooldown = 0;
    private int crouchTimer = 0;
    private boolean isCrouching = false;
    private class_243 lastPlayerPos = null;
    private int repositionCooldown = 0;

    // Strafe behaviour
    private int strafeTimer = 0;
    private int strafeDirection = 0; // -1 left, 0 none, 1 right
    private int strafeChangeTimer = 0;

    // W-tap rhythm for crits
    private boolean wTapPhase = false;
    private int wTapTimer = 0;

    // Retreat logic
    private boolean retreating = false;
    private int retreatTimer = 0;

    // Sprint state tracking
    private boolean isSprinting = false;

    public void setActive(boolean active) {
        this.active = active;
        if (!active) {
            currentTarget = null;
            mouseMovement.clearTarget();
            strafeDirection = 0;
            retreating = false;
            wTapPhase = false;
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null) {
                client.field_1724.method_5660(false);
                client.field_1690.field_1894.method_23481(false);
                client.field_1690.field_1913.method_23481(false);
                client.field_1690.field_1849.method_23481(false);
                client.field_1690.field_1867.method_23481(false);
            }
        } else {
            AiMod.LOGGER.info("Auto-attack enabled");
        }
    }

    public boolean isActive() { return active; }

    public void tick() {
        if (!active) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_746 player = client.field_1724;

        if (crouchTimer > 0) {
            crouchTimer--;
            if (crouchTimer == 0) {
                player.method_5660(false);
                isCrouching = false;
            }
        }

        if (repositionCooldown > 0) repositionCooldown--;

        // Low-health retreat
        float healthPct = player.method_6032() / player.method_6063();
        if (healthPct < 0.25f && !retreating) {
            startRetreat(client, player);
        }

        if (retreating) {
            tickRetreat(client, player);
            return;
        }

        // Find best target (prefer low-health enemies nearby)
        currentTarget = findBestTarget(client, player);

        if (currentTarget == null || !currentTarget.method_5805()) {
            currentTarget = null;
            mouseMovement.clearTarget();
            lastPlayerPos = null;
            strafeDirection = 0;
            releaseMovementKeys(client);
            return;
        }

        mouseMovement.setTarget(currentTarget);
        boolean lookingAt = mouseMovement.tick();

        double distToTarget = player.method_5739(currentTarget);

        // Update strafe behaviour
        tickStrafe(client, player, distToTarget);

        // Move toward target if too far
        if (distToTarget > ModConfig.attackRange + 1.0 && !isCrouching) {
            moveTowardTarget(client, player);
        } else if (distToTarget <= ModConfig.attackRange) {
            client.field_1690.field_1894.method_23481(false);
        }

        // W-tap rhythm (release forward momentarily before strike for crit)
        tickWTap(client, distToTarget);

        if (attackCooldown > 0) attackCooldown--;

        if (lookingAt && attackCooldown <= 0 && distToTarget <= ModConfig.attackRange) {
            client.field_1761.method_2918(player, currentTarget);
            // Vary the cooldown to simulate human timing (aim for after attack cooldown, ~10 ticks)
            attackCooldown = 9 + random.nextInt(5);
        }

        lastPlayerPos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
    }

    private void tickStrafe(class_310 client, class_746 player, double dist) {
        strafeChangeTimer--;
        if (strafeChangeTimer <= 0) {
            // Randomly change strafe direction or stop
            int roll = random.nextInt(5);
            strafeDirection = roll == 0 ? -1 : (roll == 1 ? 1 : 0);
            strafeChangeTimer = 15 + random.nextInt(25);
        }

        if (dist > ModConfig.attackRange + 2.0) {
            // Too far, don't strafe — focus on closing distance
            strafeDirection = 0;
        }

        client.field_1690.field_1913.method_23481(strafeDirection == -1);
        client.field_1690.field_1849.method_23481(strafeDirection == 1);
    }

    private void tickWTap(class_310 client, double dist) {
        if (dist > ModConfig.attackRange) return;

        wTapTimer--;
        if (wTapTimer <= 0) {
            wTapPhase = !wTapPhase;
            wTapTimer = wTapPhase ? 2 : 5 + random.nextInt(3);
        }

        if (wTapPhase) {
            client.field_1690.field_1894.method_23481(false);
        }
    }

    private void startRetreat(class_310 client, class_746 player) {
        retreating = true;
        retreatTimer = 30 + random.nextInt(20);
        AiMod.LOGGER.info("Low health — retreating!");
        if (client.field_1724 != null) {
            client.field_1724.method_7353(
                net.minecraft.class_2561.method_43470("[AI] Low health! Retreating..."), true);
        }
    }

    private void tickRetreat(class_310 client, class_746 player) {
        retreatTimer--;

        if (retreatTimer <= 0 || player.method_6032() / player.method_6063() > 0.5f) {
            retreating = false;
            releaseMovementKeys(client);
            return;
        }

        // Run away from target
        if (currentTarget != null) {
            class_243 toTarget = new class_243(currentTarget.method_23317(), currentTarget.method_23318(), currentTarget.method_23321())
                    .method_1023(player.method_23317(), player.method_23318(), player.method_23321()).method_1029();
            float fleeYaw = (float) Math.toDegrees(Math.atan2(-toTarget.field_1352, toTarget.field_1350)) + 180f;
            mouseMovement.setTargetAngles(fleeYaw, player.method_36455());
            mouseMovement.tick();
        }

        client.field_1690.field_1894.method_23481(true);
        client.field_1690.field_1867.method_23481(true);
    }

    public void onDisplacedByPlayer() {
        if (!active) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || currentTarget == null) return;

        class_746 player = client.field_1724;
        player.method_5660(true);
        isCrouching = true;
        crouchTimer = 12 + random.nextInt(12);

        if (currentTarget != null) mouseMovement.setTarget(currentTarget);
        repositionCooldown = 20;
    }

    private void moveTowardTarget(class_310 client, class_746 player) {
        class_243 dir = new class_243(currentTarget.method_23317(), currentTarget.method_23318(), currentTarget.method_23321())
                .method_1023(player.method_23317(), player.method_23318(), player.method_23321()).method_1029();
        float targetYaw = (float) Math.toDegrees(Math.atan2(-dir.field_1352, dir.field_1350));
        mouseMovement.setTargetAngles(targetYaw, player.method_36455());

        client.field_1690.field_1894.method_23481(true);
        // Sprint when far enough away
        boolean shouldSprint = player.method_5739(currentTarget) > ModConfig.attackRange + 2.0;
        client.field_1690.field_1867.method_23481(shouldSprint);
    }

    private class_1309 findBestTarget(class_310 client, class_746 player) {
        class_238 searchBox = player.method_5829().method_1014(ModConfig.attackRange + 5.0);
        List<class_1309> hostiles = client.field_1687.method_8390(
                class_1309.class,
                searchBox,
                e -> e instanceof class_1588 && e.method_5805() && e != player
        );

        if (hostiles.isEmpty()) return null;

        // Score: closer = better, lower health = higher priority
        return hostiles.stream().min(Comparator.comparingDouble(e -> {
            double dist = e.method_5858(player);
            double healthPenalty = (e.method_6032() / e.method_6063()) * 8.0; // prefer lower health
            return dist + healthPenalty;
        })).orElse(null);
    }

    private void releaseMovementKeys(class_310 client) {
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1867.method_23481(false);
    }
}
