package com.aibot.mod.features;

import com.aibot.mod.AiMod;
import com.aibot.mod.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_746;
import net.minecraft.item.*;
import java.util.*;

@Environment(EnvType.CLIENT)
public class AutoSellFeature {
    private static final int SELL_COOLDOWN_TICKS = 600;
    private static final int GUI_WAIT_TICKS = 20;

    private int sellCooldown = 0;
    private boolean active = true;
    private boolean waitingForGui = false;
    private int guiWaitTimer = 0;
    private int sellAttemptCount = 0;

    // Multiple sell command fallbacks to try in sequence
    private static final String[] SELL_COMMANDS = {
        "/sell all", "/sellall", "/sell hand", "/shop sellall",
        "/market sellall", "/ah sell all", "/trade sell"
    };
    private int sellCommandIndex = 0;

    private static final List<String> SELL_BUTTON_NAMES = List.of(
            "sell all", "sell items", "sell all items", "confirm sale",
            "confirm", "yes", "accept", "ok", "sell", "click to sell",
            "sell everything", "confirm sell", "sell all fish",
            "sell all drops", "complete sale", "proceed", "sell now",
            "quick sell", "auto sell", "bulk sell", "instant sell"
    );

    private static final Set<class_1792> FISH_ITEMS = new HashSet<>();
    private static final Set<class_1792> MOB_DROP_ITEMS = new HashSet<>();
    private static final Set<class_1792> CROP_ITEMS = new HashSet<>();
    private static final Set<class_1792> ORE_ITEMS = new HashSet<>();

    // Session stats
    private int totalSellCount = 0;

    static {
        FISH_ITEMS.add(class_1802.field_8429);
        FISH_ITEMS.add(class_1802.field_8209);
        FISH_ITEMS.add(class_1802.field_8323);
        FISH_ITEMS.add(class_1802.field_8846);

        MOB_DROP_ITEMS.add(class_1802.field_8511);
        MOB_DROP_ITEMS.add(class_1802.field_8680);
        MOB_DROP_ITEMS.add(class_1802.field_8276);
        MOB_DROP_ITEMS.add(class_1802.field_8606);
        MOB_DROP_ITEMS.add(class_1802.field_8054);
        MOB_DROP_ITEMS.add(class_1802.field_8634);
        MOB_DROP_ITEMS.add(class_1802.field_8894);
        MOB_DROP_ITEMS.add(class_1802.field_8790);
        MOB_DROP_ITEMS.add(class_1802.field_8614);
        MOB_DROP_ITEMS.add(class_1802.field_8073);
        MOB_DROP_ITEMS.add(class_1802.field_8245);
        MOB_DROP_ITEMS.add(class_1802.field_8153);
        MOB_DROP_ITEMS.add(class_1802.field_8745);
        MOB_DROP_ITEMS.add(class_1802.field_8675);
        MOB_DROP_ITEMS.add(class_1802.field_8397);
        MOB_DROP_ITEMS.add(class_1802.field_8777);
        MOB_DROP_ITEMS.add(class_1802.field_8135);
        MOB_DROP_ITEMS.add(class_1802.field_8070);
        MOB_DROP_ITEMS.add(class_1802.field_8791);
        MOB_DROP_ITEMS.add(class_1802.field_8398);
        MOB_DROP_ITEMS.add(class_1802.field_8470);
        MOB_DROP_ITEMS.add(class_1802.field_8681);
        MOB_DROP_ITEMS.add(class_1802.field_41304);
        MOB_DROP_ITEMS.add(class_1802.field_8712);
        MOB_DROP_ITEMS.add(class_1802.field_8324);
        MOB_DROP_ITEMS.add(class_1802.field_8107);
        MOB_DROP_ITEMS.add(class_1802.field_8087);
        MOB_DROP_ITEMS.add(class_1802.field_8236);

        CROP_ITEMS.add(class_1802.field_8861);
        CROP_ITEMS.add(class_1802.field_8179);
        CROP_ITEMS.add(class_1802.field_8567);
        CROP_ITEMS.add(class_1802.field_8186);
        CROP_ITEMS.add(class_1802.field_8497);
        CROP_ITEMS.add(class_1802.field_17518);
        CROP_ITEMS.add(class_1802.field_17531);
        CROP_ITEMS.add(class_1802.field_8116);
        CROP_ITEMS.add(class_1802.field_8790);

        ORE_ITEMS.add(class_1802.field_8620);
        ORE_ITEMS.add(class_1802.field_8695);
        ORE_ITEMS.add(class_1802.field_8477);
        ORE_ITEMS.add(class_1802.field_8687);
        ORE_ITEMS.add(class_1802.field_8713);
        ORE_ITEMS.add(class_1802.field_8759);
        ORE_ITEMS.add(class_1802.field_8725);
        ORE_ITEMS.add(class_1802.field_8155);
        ORE_ITEMS.add(class_1802.field_33400);
        ORE_ITEMS.add(class_1802.field_33402);
        ORE_ITEMS.add(class_1802.field_33401);
        ORE_ITEMS.add(class_1802.field_27063);
    }

    public void setActive(boolean active) { this.active = active; }
    public boolean isActive() { return active; }

    public void setSellCommand(String command) {
        SELL_COMMANDS[0] = command;
        sellCommandIndex = 0;
        AiMod.LOGGER.info("Primary sell command set to: {}", command);
    }

    public void tick() {
        if (!active) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        if (waitingForGui) {
            handleGuiWait(client);
            return;
        }

        if (sellCooldown > 0) {
            sellCooldown--;
            return;
        }

        class_746 player = client.field_1724;
        int filledSlots = countFilledSlots(player);
        int threshold = ModConfig.sellInventoryThreshold;

        if (filledSlots >= threshold && hasSellableItems(player)) {
            int sellableCount = countSellableItems(player);
            AiMod.LOGGER.info("Inventory threshold reached ({}/{} slots, {} sellable items) — selling",
                    filledSlots, 36, sellableCount);
            attemptSell(client, player, sellableCount);
        }
    }

    private void handleGuiWait(class_310 client) {
        guiWaitTimer--;

        class_437 currentScreen = client.field_1755;
        if (currentScreen instanceof class_465<?> handledScreen) {
            AiMod.LOGGER.info("GUI open after sell command: {}", currentScreen.method_25440().getString());
            boolean clicked = tryClickSellButton(client, handledScreen);
            if (clicked) {
                totalSellCount++;
                sellAttemptCount = 0; // Reset fallback counter on success
            } else {
                AiMod.LOGGER.info("No sell button found — closing screen");
                client.execute(() -> client.method_1507(null));
            }
            waitingForGui = false;
            sellCooldown = SELL_COOLDOWN_TICKS;
            return;
        }

        if (guiWaitTimer <= 0) {
            waitingForGui = false;
            // Try next fallback command if this one didn't open a GUI
            if (sellAttemptCount < SELL_COMMANDS.length - 1) {
                sellAttemptCount++;
                sellCommandIndex = sellAttemptCount % SELL_COMMANDS.length;
                AiMod.LOGGER.info("Sell command didn't open GUI, trying: {}", SELL_COMMANDS[sellCommandIndex]);
                sendCommand(client, SELL_COMMANDS[sellCommandIndex]);
                waitingForGui = true;
                guiWaitTimer = GUI_WAIT_TICKS;
            } else {
                sellCooldown = SELL_COOLDOWN_TICKS;
                sellAttemptCount = 0;
            }
        }
    }

    private boolean tryClickSellButton(class_310 client, class_465<?> screen) {
        var handler = screen.method_17577();
        List<Integer> candidates = new ArrayList<>();

        for (int i = 0; i < handler.field_7761.size(); i++) {
            var slot = handler.field_7761.get(i);
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            String itemName = stack.method_7964().getString().toLowerCase();
            for (String keyword : SELL_BUTTON_NAMES) {
                if (itemName.contains(keyword)) {
                    candidates.add(i);
                    break;
                }
            }

            if (hasLoreKeyword(stack)) {
                if (!candidates.contains(i)) candidates.add(i);
            }
        }

        if (candidates.isEmpty()) return false;

        int bestSlot = pickBestSlot(handler, candidates);
        AiMod.LOGGER.info("Clicking sell button at slot {} ('{}')",
                bestSlot, handler.field_7761.get(bestSlot).method_7677().method_7964().getString());

        client.field_1761.method_2906(
                handler.field_7763, bestSlot, 0, class_1713.field_7790, client.field_1724
        );
        return true;
    }

    private boolean hasLoreKeyword(class_1799 stack) {
        var lore = stack.method_58694(net.minecraft.class_9334.field_49632);
        if (lore == null) return false;
        for (class_2561 line : lore.comp_2400()) {
            String text = line.getString().toLowerCase();
            for (String keyword : SELL_BUTTON_NAMES) {
                if (text.contains(keyword)) return true;
            }
        }
        return false;
    }

    private int pickBestSlot(net.minecraft.class_1703 handler, List<Integer> candidates) {
        String[] priority = {"sell all", "sell everything", "sell items", "quick sell",
                "auto sell", "confirm", "yes", "ok", "sell"};
        for (String keyword : priority) {
            for (int slotIdx : candidates) {
                String name = handler.field_7761.get(slotIdx).method_7677().method_7964().getString().toLowerCase();
                if (name.contains(keyword)) return slotIdx;
            }
        }
        return candidates.get(0);
    }

    private void attemptSell(class_310 client, class_746 player, int sellableCount) {
        String command = SELL_COMMANDS[sellCommandIndex % SELL_COMMANDS.length];
        sendCommand(client, command);
        waitingForGui = true;
        guiWaitTimer = GUI_WAIT_TICKS;

        player.method_7353(class_2561.method_43470("[AI] Selling " + sellableCount + " items (" + command + ")..."), true);
        AiMod.LOGGER.info("Sent sell command: {}", command);
    }

    private void sendCommand(class_310 client, String command) {
        if (client.field_1724 == null) return;
        try {
            String cmd = command.startsWith("/") ? command.substring(1) : command;
            client.field_1724.field_3944.method_45730(cmd);
        } catch (Exception e) {
            AiMod.LOGGER.error("Failed to send sell command: {}", e.getMessage());
        }
    }

    private boolean hasSellableItems(class_746 player) {
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (!stack.method_7960() && isSellable(stack.method_7909())) return true;
        }
        return false;
    }

    private boolean isSellable(class_1792 item) {
        return FISH_ITEMS.contains(item) || MOB_DROP_ITEMS.contains(item)
                || CROP_ITEMS.contains(item) || ORE_ITEMS.contains(item);
    }

    private int countFilledSlots(class_746 player) {
        int count = 0;
        for (int i = 0; i < 36; i++) {
            if (!player.method_31548().method_5438(i).method_7960()) count++;
        }
        return count;
    }

    public int countSellableItems(class_746 player) {
        int count = 0;
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (!stack.method_7960() && isSellable(stack.method_7909())) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    public int getTotalSellCount() { return totalSellCount; }
}
