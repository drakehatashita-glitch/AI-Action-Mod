package com.aibot.mod.macro;

import com.aibot.mod.AiMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class MovementRecorder {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path RECORDINGS_DIR = FabricLoader.getInstance().getGameDir().resolve("aimod/recordings");

    private boolean recording = false;
    private final List<ActionFrame> frames = new ArrayList<>();
    private String recordingName = "last";

    public void startRecording(String name) {
        frames.clear();
        recordingName = name;
        recording = true;
        AiMod.LOGGER.info("Recording started: {}", name);

        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[AI] Recording started — press [R] to stop."), true);
        }
    }

    public void stopRecording() {
        if (!recording) return;
        recording = false;

        class_310 client = class_310.method_1551();

        if (frames.isEmpty()) {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("[AI] Recording stopped — no frames captured."), true);
            }
            return;
        }

        compressFrames();
        save(recordingName);
        AiMod.LOGGER.info("Recording stopped: {} frames saved as '{}'", frames.size(), recordingName);

        if (client.field_1724 != null) {
            client.field_1724.method_7353(
                class_2561.method_43470("[AI] Saved " + frames.size() + " frames as '" + recordingName + "'."), true
            );
        }
    }

    public void tick() {
        if (!recording) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_746 player = client.field_1724;
        ActionFrame frame = new ActionFrame();

        frame.forward = client.field_1690.field_1894.method_1434();
        frame.backward = client.field_1690.field_1881.method_1434();
        frame.left = client.field_1690.field_1913.method_1434();
        frame.right = client.field_1690.field_1849.method_1434();
        frame.jumping = client.field_1690.field_1903.method_1434();
        frame.sneaking = client.field_1690.field_1832.method_1434();
        frame.sprinting = client.field_1690.field_1867.method_1434();
        frame.attacking = client.field_1690.field_1886.method_1434();
        frame.using = client.field_1690.field_1904.method_1434();
        frame.yaw = player.method_36454();
        frame.pitch = player.method_36455();

        frames.add(frame);
    }

    private void compressFrames() {
        if (frames.size() < 2) return;
        List<ActionFrame> compressed = new ArrayList<>();
        ActionFrame current = frames.get(0);

        for (int i = 1; i < frames.size(); i++) {
            ActionFrame next = frames.get(i);
            if (framesEqual(current, next) && current.tickDuration < 20) {
                current.tickDuration++;
            } else {
                compressed.add(current);
                current = next.copy();
            }
        }
        compressed.add(current);
        frames.clear();
        frames.addAll(compressed);
    }

    private boolean framesEqual(ActionFrame a, ActionFrame b) {
        return a.forward == b.forward && a.backward == b.backward
                && a.left == b.left && a.right == b.right
                && a.jumping == b.jumping && a.sneaking == b.sneaking
                && a.sprinting == b.sprinting && a.attacking == b.attacking
                && a.using == b.using
                && Math.abs(a.yaw - b.yaw) < 1.0f
                && Math.abs(a.pitch - b.pitch) < 1.0f;
    }

    public void save(String name) {
        try {
            Files.createDirectories(RECORDINGS_DIR);
            Path file = RECORDINGS_DIR.resolve(sanitize(name) + ".json");
            Files.writeString(file, GSON.toJson(frames));
            AiMod.LOGGER.info("Saved recording to {}", file);
        } catch (IOException e) {
            AiMod.LOGGER.error("Failed to save recording", e);
        }
    }

    public void saveFrames(String name, List<ActionFrame> framesToSave) {
        try {
            Files.createDirectories(RECORDINGS_DIR);
            Path file = RECORDINGS_DIR.resolve(sanitize(name) + ".json");
            Files.writeString(file, GSON.toJson(framesToSave));
            AiMod.LOGGER.info("Saved {} frames as '{}'", framesToSave.size(), name);
        } catch (IOException e) {
            AiMod.LOGGER.error("Failed to save frames as '{}'", name, e);
        }
    }

    public boolean delete(String name) {
        try {
            Path file = RECORDINGS_DIR.resolve(sanitize(name) + ".json");
            return Files.deleteIfExists(file);
        } catch (IOException e) {
            AiMod.LOGGER.error("Failed to delete recording: {}", name, e);
            return false;
        }
    }

    public List<ActionFrame> load(String name) {
        try {
            Path file = RECORDINGS_DIR.resolve(sanitize(name) + ".json");
            if (!Files.exists(file)) return null;
            String json = Files.readString(file);
            ActionFrame[] arr = GSON.fromJson(json, ActionFrame[].class);
            return arr != null ? new ArrayList<>(List.of(arr)) : null;
        } catch (IOException e) {
            AiMod.LOGGER.error("Failed to load recording: {}", name, e);
            return null;
        }
    }

    public List<ActionFrame> getLastFrames() {
        return new ArrayList<>(frames);
    }

    public boolean isRecording() { return recording; }

    public String getRecordingName() { return recordingName; }

    public List<String> listRecordings() {
        try {
            Files.createDirectories(RECORDINGS_DIR);
            List<String> names = new ArrayList<>();
            Files.list(RECORDINGS_DIR)
                    .filter(p -> p.toString().endsWith(".json"))
                    .sorted()
                    .forEach(p -> names.add(p.getFileName().toString().replace(".json", "")));
            return names;
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    private String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }
}
