package com.aibot.mod.macro;

import com.aibot.mod.AiMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.List;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class MovementPlayback {
    private boolean playing = false;
    private boolean paused = false;
    private List<ActionFrame> frames;
    private int currentFrameIndex = 0;
    private int currentFrameTick = 0;
    private boolean looping = true;
    private int loopCount = 0;

    // Mouse variation flags
    private boolean mouseLocked = false;

    // Per-loop variation (recalculated each loop)
    private float yawVariation = 0f;
    private float pitchVariation = 0f;
    private float timingDriftFactor = 1.0f;

    // Per-tick micro-noise
    private float yawNoise = 0f;
    private float pitchNoise = 0f;
    private int noiseRefreshTimer = 0;

    private int extraPauseTicks = 0;
    private int variationRefreshTimer = 0;

    // Teleport detection
    private class_243 lastPosition = null;
    private static final double TELEPORT_THRESHOLD_SQ = 64.0; // 8 blocks squared
    private boolean scanning = false;
    private float scanYaw = 0f;
    private int scanDirection = 1;
    private int scanTimer = 0;

    private static final Random RANDOM = new Random();

    public void start(List<ActionFrame> frames, boolean loop) {
        this.frames = frames;
        this.looping = loop;
        this.currentFrameIndex = 0;
        this.currentFrameTick = 0;
        this.loopCount = 0;
        this.playing = true;
        this.paused = false;
        this.scanning = false;
        this.lastPosition = null;
        refreshVariation();
        AiMod.LOGGER.info("Playback started: {} frames, loop={}", frames.size(), loop);

        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[AI] Playback started. Press [P] to stop."), true);
        }
    }

    public void stop() {
        if (!playing) return;
        playing = false;
        paused = false;
        scanning = false;
        releaseAllKeys();
        AiMod.LOGGER.info("Playback stopped after {} loops.", loopCount);

        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[AI] Playback stopped."), true);
        }
    }

    public void pause() {
        if (!playing) return;
        paused = true;
        releaseAllKeys();
    }

    public void resume() {
        paused = false;
    }

    public void setMouseLocked(boolean locked) {
        this.mouseLocked = locked;
    }

    public void tick() {
        if (!playing || frames == null || frames.isEmpty()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        // --- Teleport detection ---
        class_243 pos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
        if (lastPosition != null && !paused && !scanning) {
            double distSq = pos.method_1025(lastPosition);
            if (distSq > TELEPORT_THRESHOLD_SQ) {
                AiMod.LOGGER.warn("Teleport detected! Stopping playback and entering scan mode.");
                releaseAllKeys();
                scanning = true;
                scanYaw = client.field_1724.method_36454();
                scanTimer = 0;
                client.field_1724.method_7353(
                    class_2561.method_43470("[AI] Teleported! Scanning... Press [P] to resume playback."), true);
            }
        }
        lastPosition = pos;

        // --- Scan mode ---
        if (scanning) {
            tickScan(client);
            return;
        }

        if (paused) {
            return;
        }

        if (extraPauseTicks > 0) {
            extraPauseTicks--;
            releaseAllKeys();
            return;
        }

        variationRefreshTimer--;
        if (variationRefreshTimer <= 0) {
            refreshVariation();
        }

        noiseRefreshTimer--;
        if (noiseRefreshTimer <= 0) {
            if (!mouseLocked) {
                yawNoise = (RANDOM.nextFloat() - 0.5f) * 0.8f;
                pitchNoise = (RANDOM.nextFloat() - 0.5f) * 0.4f;
            } else {
                yawNoise = 0f;
                pitchNoise = 0f;
            }
            noiseRefreshTimer = 3 + RANDOM.nextInt(5);
        }

        ActionFrame frame = frames.get(currentFrameIndex);
        applyFrame(client, frame);

        currentFrameTick++;
        int effectiveDuration = mouseLocked
            ? frame.tickDuration
            : Math.max(1, Math.round(frame.tickDuration * timingDriftFactor));

        if (currentFrameTick >= effectiveDuration) {
            currentFrameTick = 0;
            currentFrameIndex++;

            if (!mouseLocked && RANDOM.nextInt(100) < 3) {
                extraPauseTicks = RANDOM.nextInt(3) + 1;
            }

            if (currentFrameIndex >= frames.size()) {
                loopCount++;
                if (looping) {
                    currentFrameIndex = 0;
                    refreshVariation();
                    extraPauseTicks = 5 + RANDOM.nextInt(20);
                } else {
                    stop();
                }
            }
        }
    }

    private void tickScan(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) return;

        scanTimer++;

        // Sweep yaw back and forth slowly, bob pitch slightly
        scanYaw += scanDirection * 0.8f;
        float pitch = (float)(Math.sin(scanTimer * 0.05) * 15.0);

        if (Math.abs(scanYaw - player.method_36454()) > 60f) {
            scanDirection *= -1;
        }

        player.method_36456(scanYaw);
        player.method_36457(pitch);
    }

    public void stopScan() {
        scanning = false;
    }

    private void applyFrame(class_310 client, ActionFrame frame) {
        class_746 player = client.field_1724;
        if (player == null) return;

        client.field_1690.field_1894.method_23481(frame.forward);
        client.field_1690.field_1881.method_23481(frame.backward);
        client.field_1690.field_1913.method_23481(frame.left);
        client.field_1690.field_1849.method_23481(frame.right);
        client.field_1690.field_1903.method_23481(frame.jumping);
        client.field_1690.field_1832.method_23481(frame.sneaking);
        client.field_1690.field_1867.method_23481(frame.sprinting || (frame.forward && !frame.sneaking && RANDOM.nextFloat() < 0.95f));
        client.field_1690.field_1886.method_23481(frame.attacking);
        client.field_1690.field_1904.method_23481(frame.using);

        if (mouseLocked) {
            player.method_36456(frame.yaw);
            player.method_36457(frame.pitch);
        } else {
            float newYaw = frame.yaw + yawVariation + yawNoise;
            float newPitch = Math.max(-90f, Math.min(90f, frame.pitch + pitchVariation + pitchNoise));
            player.method_36456(newYaw);
            player.method_36457(newPitch);
        }
    }

    private void refreshVariation() {
        if (!mouseLocked) {
            yawVariation = (RANDOM.nextFloat() - 0.5f) * 10f;
            pitchVariation = (RANDOM.nextFloat() - 0.5f) * 5f;
            timingDriftFactor = 0.90f + RANDOM.nextFloat() * 0.20f;
        } else {
            yawVariation = 0f;
            pitchVariation = 0f;
            timingDriftFactor = 1.0f;
        }
        variationRefreshTimer = 60 + RANDOM.nextInt(80);
    }

    private void releaseAllKeys() {
        class_310 client = class_310.method_1551();
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1881.method_23481(false);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1903.method_23481(false);
        client.field_1690.field_1832.method_23481(false);
        client.field_1690.field_1867.method_23481(false);
        client.field_1690.field_1886.method_23481(false);
        client.field_1690.field_1904.method_23481(false);
    }

    public boolean isPlaying() { return playing; }
    public boolean isPaused() { return paused; }
    public boolean isScanning() { return scanning; }
    public boolean isMouseLocked() { return mouseLocked; }
    public int getLoopCount() { return loopCount; }
    public int getCurrentFrame() { return currentFrameIndex; }
    public int getTotalFrames() { return frames != null ? frames.size() : 0; }
}
