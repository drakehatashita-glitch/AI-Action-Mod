package com.aibot.mod.macro;

import com.aibot.mod.AiMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.List;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class MovementPlayback {
    private boolean playing = false;
    private boolean paused  = false;
    private List<ActionFrame> frames;
    private int currentFrameIndex = 0;
    private int currentFrameTick  = 0;
    private boolean looping   = true;
    private int loopCount     = 0;

    private boolean mouseLocked = false;

    // Per-loop variation
    private float yawVariation   = 0f;
    private float pitchVariation = 0f;
    private float timingDriftFactor = 1.0f;

    // Per-tick micro-noise
    private float yawNoise    = 0f;
    private float pitchNoise  = 0f;
    private int noiseRefreshTimer    = 0;
    private int variationRefreshTimer = 0;

    private int extraPauseTicks = 0;

    // Anti-pattern: human break between loops
    private int loopsSinceBreak = 0;
    private static final int MAX_LOOPS_BEFORE_BREAK = 12;
    private boolean takingBreak = false;
    private int breakDurationTicks = 0;

    // Teleport detection
    private class_243 lastPosition = null;
    private static final double TELEPORT_THRESHOLD_SQ = 64.0;
    private boolean scanning = false;
    private float scanYaw = 0f;
    private int scanDirection = 1;
    private int scanTimer = 0;

    private static final Random RANDOM = new Random();

    // -------------------------------------------------------------------------
    // Control
    // -------------------------------------------------------------------------

    public void start(List<ActionFrame> frames, boolean loop) {
        this.frames = frames;
        this.looping = loop;
        this.currentFrameIndex = 0;
        this.currentFrameTick  = 0;
        this.loopCount         = 0;
        this.loopsSinceBreak   = 0;
        this.playing           = true;
        this.paused            = false;
        this.scanning          = false;
        this.takingBreak       = false;
        this.lastPosition      = null;
        refreshVariation();
        AiMod.LOGGER.info("Playback started: {} frames, loop={}", frames.size(), loop);

        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(
                class_2561.method_43470("[AI] Playback started. Press [P] to stop."), true);
        }
    }

    public void stop() {
        if (!playing) return;
        playing  = false;
        paused   = false;
        scanning = false;
        takingBreak = false;
        releaseAllKeys();
        AiMod.LOGGER.info("Playback stopped after {} loops.", loopCount);

        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[AI] Playback stopped."), true);
        }
    }

    public void pause()  { if (playing) { paused = true;  releaseAllKeys(); } }
    public void resume() { paused = false; }

    public void setMouseLocked(boolean locked) { this.mouseLocked = locked; }

    // -------------------------------------------------------------------------
    // Main tick
    // -------------------------------------------------------------------------

    public void tick() {
        if (!playing || frames == null || frames.isEmpty()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        // Teleport detection
        class_243 pos = new class_243(
            client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
        if (lastPosition != null && !paused && !scanning) {
            double distSq = pos.method_1025(lastPosition);
            if (distSq > TELEPORT_THRESHOLD_SQ) {
                AiMod.LOGGER.warn("Teleport detected! Entering scan mode.");
                releaseAllKeys();
                scanning = true;
                scanYaw  = client.field_1724.method_36454();
                scanTimer = 0;
                client.field_1724.method_7353(
                    class_2561.method_43470("[AI] Teleported — scanning environment."), true);
            }
        }
        lastPosition = pos;

        if (scanning) { tickScan(client); return; }
        if (paused)   return;

        // Human break between loops
        if (takingBreak) {
            breakDurationTicks--;
            releaseAllKeys();
            if (breakDurationTicks <= 0) {
                takingBreak = false;
                loopsSinceBreak = 0;
                AiMod.LOGGER.info("Break over, resuming playback");
            }
            return;
        }

        if (extraPauseTicks > 0) {
            extraPauseTicks--;
            releaseAllKeys();
            return;
        }

        variationRefreshTimer--;
        if (variationRefreshTimer <= 0) refreshVariation();

        noiseRefreshTimer--;
        if (noiseRefreshTimer <= 0) {
            if (!mouseLocked) {
                yawNoise   = (float)(RANDOM.nextGaussian() * 0.35f);
                pitchNoise = (float)(RANDOM.nextGaussian() * 0.18f);
            } else {
                yawNoise = pitchNoise = 0f;
            }
            noiseRefreshTimer = 3 + RANDOM.nextInt(6);
        }

        ActionFrame frame = frames.get(currentFrameIndex);
        applyFrame(client, frame);

        currentFrameTick++;
        int effectiveDuration = mouseLocked
            ? frame.tickDuration
            : Math.max(1, Math.round(frame.tickDuration * timingDriftFactor));

        if (currentFrameTick >= effectiveDuration) {
            currentFrameTick = 0;
            currentFrameIndex++;

            // Occasional micro-pause mid-sequence
            if (!mouseLocked && RANDOM.nextInt(120) < 3) {
                extraPauseTicks = RANDOM.nextInt(4) + 1;
            }

            if (currentFrameIndex >= frames.size()) {
                loopCount++;
                loopsSinceBreak++;

                if (looping) {
                    currentFrameIndex = 0;
                    refreshVariation();
                    extraPauseTicks = 5 + RANDOM.nextInt(15);

                    if (loopsSinceBreak >= MAX_LOOPS_BEFORE_BREAK
                            && RANDOM.nextFloat() < 0.5f) {
                        startHumanBreak(client);
                    }
                } else {
                    stop();
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Apply a single frame to the game
    // -------------------------------------------------------------------------

    private void applyFrame(class_310 client, ActionFrame frame) {
        class_746 player = client.field_1724;
        if (player == null) return;

        // --- Movement keys ---
        client.field_1690.field_1894.method_23481(frame.forward);
        client.field_1690.field_1881.method_23481(frame.backward);
        client.field_1690.field_1913.method_23481(frame.left);
        client.field_1690.field_1849.method_23481(frame.right);
        client.field_1690.field_1903.method_23481(frame.jumping);
        client.field_1690.field_1832.method_23481(frame.sneaking);

        boolean shouldSprint = frame.sprinting
                || (frame.forward && !frame.sneaking && RANDOM.nextFloat() < 0.93f);
        client.field_1690.field_1867.method_23481(shouldSprint);

        client.field_1690.field_1886.method_23481(frame.attacking);
        client.field_1690.field_1904.method_23481(frame.using);

        // --- Look direction ---
        if (mouseLocked) {
            player.method_36456(frame.yaw);
            player.method_36457(frame.pitch);
        } else {
            float newYaw   = frame.yaw + yawVariation + yawNoise;
            float newPitch = Math.max(-90f,
                Math.min(90f, frame.pitch + pitchVariation + pitchNoise));
            player.method_36456(newYaw);
            player.method_36457(newPitch);
        }

        // --- Hotbar slot change (simulate key press rather than direct field write) ---
        if (frame.hotbarSlot >= 0 && frame.hotbarSlot <= 8) {
            final int slot = frame.hotbarSlot;
            client.field_1690.field_1852[slot].method_23481(true);
            client.execute(() -> client.field_1690.field_1852[slot].method_23481(false));
        }

        // --- One-tick event actions ---
        if (frame.dropItem) {
            // Press and immediately release Q (drops one item from hand)
            client.field_1690.field_1869.method_23481(true);
            client.execute(() -> client.field_1690.field_1869.method_23481(false));
        }

        if (frame.swapHands) {
            client.field_1690.field_1831.method_23481(true);
            client.execute(() -> client.field_1690.field_1831.method_23481(false));
        }

        if (frame.pickBlock) {
            client.field_1690.field_1871.method_23481(true);
            client.execute(() -> client.field_1690.field_1871.method_23481(false));
        }

        // --- Chat message or command ---
        if (frame.chatMessage != null && !frame.chatMessage.isBlank()) {
            final String msg = frame.chatMessage;
            client.execute(() -> {
                if (client.method_1562() == null) return;
                if (msg.startsWith("/")) {
                    // Strip leading slash — sendChatCommand expects bare command
                    client.method_1562().method_45730(msg.substring(1));
                } else {
                    client.method_1562().method_45729(msg);
                }
                AiMod.LOGGER.info("[Playback] Sent {}: {}",
                    msg.startsWith("/") ? "command" : "chat", msg);
            });
        }
    }

    // -------------------------------------------------------------------------
    // Scan behaviour (post-teleport)
    // -------------------------------------------------------------------------

    private void tickScan(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) return;

        scanTimer++;
        scanYaw += scanDirection * 0.6f + (RANDOM.nextFloat() - 0.5f) * 0.2f;
        float pitch = (float)(Math.sin(scanTimer * 0.04) * 18.0);

        if (Math.abs(scanYaw - player.method_36454()) > 55f) scanDirection *= -1;

        player.method_36456(scanYaw);
        player.method_36457(pitch);
    }

    public void stopScan() { scanning = false; }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private void startHumanBreak(class_310 client) {
        takingBreak = true;
        breakDurationTicks = 60 + RANDOM.nextInt(180);
        AiMod.LOGGER.info("Taking human-like break for {} ticks", breakDurationTicks);

        if (client.field_1724 != null && com.aibot.mod.config.ModConfig.debugMode) {
            client.field_1724.method_7353(
                class_2561.method_43470("[AI] Taking a short break..."), true);
        }
    }

    private void refreshVariation() {
        if (!mouseLocked) {
            yawVariation       = (float)(RANDOM.nextGaussian() * 4.5f);
            pitchVariation     = (float)(RANDOM.nextGaussian() * 2.5f);
            timingDriftFactor  = 0.88f + RANDOM.nextFloat() * 0.24f;
        } else {
            yawVariation = pitchVariation = 0f;
            timingDriftFactor = 1.0f;
        }
        variationRefreshTimer = 50 + RANDOM.nextInt(90);
    }

    private void releaseAllKeys() {
        class_310 client = class_310.method_1551();
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1881.method_23481(false);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1903.method_23481(false);
        client.field_1690.field_1832.method_23481(false);
        client.field_1690.field_1867.method_23481(false);
        client.field_1690.field_1886.method_23481(false);
        client.field_1690.field_1904.method_23481(false);
        client.field_1690.field_1869.method_23481(false);
        client.field_1690.field_1831.method_23481(false);
        client.field_1690.field_1871.method_23481(false);
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public boolean isPlaying()      { return playing; }
    public boolean isPaused()       { return paused; }
    public boolean isScanning()     { return scanning; }
    public boolean isMouseLocked()  { return mouseLocked; }
    public int getLoopCount()       { return loopCount; }
    public int getCurrentFrame()    { return currentFrameIndex; }
    public int getTotalFrames()     { return frames != null ? frames.size() : 0; }
    public boolean isTakingBreak()  { return takingBreak; }
}
